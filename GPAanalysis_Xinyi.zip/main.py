print('Student GPA Analyzer & Predictor')
courses = []
grades = []
weights = []

def input_data():
    """input the data"""
    print("Enter your courses (type 'done' to finish):")
    while True:
        course = input("Course name: ")
        if course.lower() == 'done':
            break
        grade = float(input("Grade (0-100): "))
        level = input("Is this AP? (yes/no): ")
        if level.lower() == "yes":
            weight = 1.1
        else:
            weight = 1.0
        courses.append(course)
        grades.append(grade)
        weights.append(weight)
        
def calculate_gpa():
    """ Calculate the GPA """
    if len(grades) == 0:
        print("No data available.")
        return 0
    total = 0
    for i in range(len(grades)):
        gpa_value = convert_to_gpa(grades[i])
        total += gpa_value*weights[i]
    gpa = total / len(grades)
    return gpa
    
def convert_to_gpa(score):
    """ Convert your grades to GPA"""
    if score >= 90:
        return 4.0
    elif score >= 80:
        return 3.0
    elif score >= 70:
        return 2.0
    elif score >= 60:
        return 1.0
    else:
        return 0.0
        
def analyze_performance():
    """Analyze your performance"""
    max_grade = max(grades)
    min_grade = min(grades)
    
    best_course = courses[grades.index(max_grade)]
    worst_course = courses[grades.index(min_grade)]
    
    print("\n--- Performance Analysis ---")
    print(f"Best subject: {best_course} ({max_grade})")
    print(f"Weakest subject: {worst_course} ({min_grade})")
    
def predict_improvement():
    if len(grades) == 0:
        print("No data available.")
        return
    print("\n--- GPA Prediction ---")
    subject = input("Which subject do you want to improve?")
    if subject not in courses:
        print("Course not found.")
        return
    increase = float(input("Increase by how many points? "))
    new_grades = grades.copy()
    index = courses.index(subject)
    new_grades[index] += increase
    
    if new_grades[index]>100:
        new_grades[index] = 100
        
    total = 0 
    for i in range(len(new_grades)):
        gpa_value = convert_to_gpa(new_grades[i])
        total += gpa_value*weights[i]
        
    new_gpa = total / len(new_grades)
    print(f"New GPA if improved: {new_gpa:.2f}")
    
def analyze_grade_jump():
    if len(grades) == 0:
        print("No data available.")
        return
    print("\n--- Grade Impact Analysis ---")
    subject = input("Enter subject to analyze: ")
    if subject not in courses:
        print("Course not found.")
        return
    
    index = courses.index(subject)
    current_score = grades[index]
    current_gpa_value = convert_to_gpa(current_score)
    
    print(f"\nCurrent score: {current_score}")
    print(f"Current GPA value : {current_gpa_value}")
    
    print("\nTrying improvements from +1 to +10 points:")
    for increase in range(1,11):
        new_score = current_score + increase
        
        if new_score > 100:
            new_score = 100
            
        new_gpa_value = convert_to_gpa(new_score)
        if new_gpa_value > current_gpa_value:
            print(f"+{increase} + GPA increse to {new_gpa_value}")
        else:
            print(f"+{increase} + GPA stays {new_gpa_value}")
def menu():
    while True:
        print("\n=== GPA Analyzer ===")
        print("1. Input Data")
        print("2. Calculate GPA")
        print("3. Analyze Performance")
        print("4. Predict GPA Improvement")
        print("5. Grade Impact Analysis")
        print("6. Exit")
        
        choice = input("Choose an option: ")
        
        if choice == "1":
            input_data()
        elif choice == "2":
            gpa = calculate_gpa()
            print(f"Your GPA: {gpa:.2f}")
        elif choice == "3":
            analyze_performance()
        elif choice == "4":
            predict_improvement()
        elif choice == "5":
            analyze_grade_jump()
        elif choice == "6":
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")
            
menu()